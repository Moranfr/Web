package grometrix;
import java.util.Random;
public class polygon {
	
	Point [] points;
	
	Random rand = new Random();
	
	public int location=0;
	
	public polygon (int pointCount)
	{
		//generate random point to array
		
		this.location=pointCount;
		
		points=new Point[3];
		
		for(int i=0;i<pointCount;i++)
		{
			int  n = rand.nextInt(100) + 0;
			points[i]=new Point(n,n);
			
		}
		
		
		System.out.print(toString(points[0]));
		
	}

	public String toString(Point p)
	{
		p.toString();
		System.out.print(p.toString());
		return null;
	}
	
  //highestPoint();
	
public int highestPoint(Point p)
{int max=0;
	for(int i=0;i<this.location;i++)
	{
		if(p.gety()<max)
		{
			
			
			
		}
		
	}
}
	//lowestPoint();
	//double maxDistance();
	
}