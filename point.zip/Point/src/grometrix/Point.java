package grometrix;
public class Point {
	
	private int x;
	private int y;
	
	
	// Contractor
	
	public Point(int x,int y)
	{
		setx(x);
		sety(y);
	}
	
 //getters and setters
	
	public int getx()
	{
		return this.x;
	}
	
	public void setx(int x)
	{
		if(x<=0||x>=100)
		{
	   System.out.print("worng input");
		}
		else
		{
			  this.x=x;
		}
	}
	public int gety()
	{
	
		return this.y;
		
	}
	public void sety(int y)
	{
		if(x<=0||x>=100)
		{
	   System.out.print("worng input");
		}
		else
		{
			this.y=y;
		}
		
	}
	
	//toString (x,y)
	
	public String toString()
	{
		return "("+"this.x"+","+"this.y"+")";
	}
	
	//double distance (point other)

	public double distance(Point p) 
	{
	double distance=Math.sqrt((p.x-this.x)*(p.x-this.x)+(p.y-this.y)*(p.y-this.y));
	
	return distance;
	}
	
}

